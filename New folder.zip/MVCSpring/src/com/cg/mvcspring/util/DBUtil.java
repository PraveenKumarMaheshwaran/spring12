package com.cg.mvcspring.util;

import java.sql.*;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil {
	static Connection con;
	
	static
	{
		InitialContext context;
		try{
			context=new InitialContext();
		DataSource datasource=(DataSource) context.lookup("java:/jdbc/TestDS");
		con=datasource.getConnection();
		}
		catch(NamingException | SQLException e)
		{
			e.printStackTrace();
		}
	}
	public static Connection getConnect()
	{
		return con;
	}
	

}
