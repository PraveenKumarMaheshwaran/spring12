package com.cg.mvcspring.bean;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

public class Employee {
	
	@NotNull(message="Id cannot be empty")
	Integer empId;
	@NotEmpty(message="Name cannot be empty")
	@Pattern(regexp="[A-Z]{1}[a-z]{2,}",message="Format is wrong")
	
	String empName;
	
	@NotNull(message="Salary cannot be empty")
	Integer empSal;

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Integer getEmpSal() {
		return empSal;
	}

	public void setEmpSal(Integer empSal) {
		this.empSal = empSal;
	}
	
	
	
	

}
