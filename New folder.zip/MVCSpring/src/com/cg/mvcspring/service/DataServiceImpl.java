package com.cg.mvcspring.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cg.mvcspring.bean.Employee;
import com.cg.mvcspring.dao.DataDao;

@Service
@Component("service")
public class DataServiceImpl implements DataService{
@Autowired
DataDao dao;
	@Override
	public ArrayList<Employee> showData() {
		// TODO Auto-generated method stub
		return dao.showData();
	}
	@Override
	public Employee addEmployee(Employee obj) {
		// TODO Auto-generated method stub
		return dao.addEmployee(obj);
	}
	@Override
	public Employee deleteEmployee(Employee obj) {
		// TODO Auto-generated method stub
		return dao.deleteEmployee(obj);
	}
	

}
