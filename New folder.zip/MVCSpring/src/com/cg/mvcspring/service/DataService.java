package com.cg.mvcspring.service;

import java.util.ArrayList;

import com.cg.mvcspring.bean.Employee;

public interface DataService {
	ArrayList<Employee> showData();
	public Employee addEmployee(Employee obj);
	public Employee deleteEmployee(Employee obj);


}
