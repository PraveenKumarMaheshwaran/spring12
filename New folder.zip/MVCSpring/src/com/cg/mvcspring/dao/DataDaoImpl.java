package com.cg.mvcspring.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cg.mvcspring.bean.Employee;
import com.cg.mvcspring.util.DBUtil;
@Repository
@Component("dao")
public class DataDaoImpl implements DataDao{


	Connection con;
	public DataDaoImpl()
	{
		con=DBUtil.getConnect();
	}

	@Override
	public ArrayList<Employee> showData() {
		// TODO Auto-generated method stub
		ArrayList<Employee> list=new ArrayList<Employee>();
		String sql="SELECT * FROM EMPLOYEE";
		try{
			Statement stat=con.createStatement();
			ResultSet rst=stat.executeQuery(sql);
			while(rst.next())
			{
				Employee emp=new Employee();
				emp.setEmpId(rst.getInt(1));
				emp.setEmpName(rst.getString(2));
				emp.setEmpSal(rst.getInt(3));
				list.add(emp);
			}
		}
			catch(SQLException e)
		{
				e.printStackTrace();
		}
		return list;
	}
	public Employee addEmployee(Employee obj)
	
	{
		Employee ref=null;
		String sql="INSERT INTO EMPLOYEE VALUES (?,?,?)";
		try{
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setInt(1, obj.getEmpId());
		pst.setString(2, obj.getEmpName());
		pst.setInt(3, obj.getEmpSal());
		int row=pst.executeUpdate();
		if(row==1)
		{
			ref=obj;
			
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return ref;
		
	}

	@Override
	public Employee deleteEmployee(Employee obj) {
		// TODO Auto-generated method stub
		Employee ref=null;
		String sql="DELETE FROM EMPLOYEE WHERE EMPID=?";
		try{
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setInt(1, obj.getEmpId());
		int row=pst.executeUpdate();
		if(row==1)
		{
			ref=obj;
			
		}
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return ref;
	}

}
