package com.cg.mvcspring.dao;

import java.util.ArrayList;

import com.cg.mvcspring.bean.Employee;

public interface DataDao {
	ArrayList<Employee> showData();
	public Employee addEmployee(Employee obj);
	public Employee deleteEmployee(Employee obj);
}
