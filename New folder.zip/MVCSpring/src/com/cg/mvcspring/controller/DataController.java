package com.cg.mvcspring.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.mvcspring.bean.Employee;
import com.cg.mvcspring.service.DataService;

@Controller
@RequestMapping("ctrl")
public class DataController {
	
	@Autowired
	DataService service;
	@RequestMapping("/show")
	public String showData(Model model)
	{
		String viewname;
		ArrayList<Employee>list=service.showData();
		if(list.size()!=0)
		{
			viewname="list";
			model.addAttribute("empList",list);
		
		}
		else
		{
			viewname="error";
			model.addAttribute("message", "no data found");
		
			
		}
		return viewname;
		
	}
	@RequestMapping("/addEmp")
	//public String addEmployee
	//(@RequestParam("empId")int id,@RequestParam("empName")String name,@RequestParam("empSal")int sal,Model model)
	public String addEmployee(@ModelAttribute("employee") @Valid Employee employee,BindingResult result,Model model)
	{
		String viewname=null;
		/*Employee emp=new Employee();
		emp.setEmpId(id);
		emp.setEmpName(name);
		emp.setEmpSal(sal);*/
		if(result.hasErrors())
		{
			viewname="emp";
		}
			
		else{
			
			Employee ref=service.addEmployee(employee);
			if(ref!=null)
			{
				model.addAttribute("employee", employee);
			viewname="success";
			}
			else{
				model.addAttribute("message", "unable to add");
				viewname="error";
			}
		}
		
		
		return viewname;
		
	}
	
	@RequestMapping("add")
	public String moveToEmployee(Model model)
	{
		Employee employee=new Employee();
		model.addAttribute("employee", employee);
		return "emp";
		
	}
	@RequestMapping("/deleteemp")
	//public String deleteEmployee(@RequestParam("empId")int id,Model model)
	public String deleteEmployee(@ModelAttribute("employee") @Valid Employee employee,BindingResult result,Model model)
	{
		String viewname=null;
		/*Employee emp=new Employee();
		emp.setEmpId(id);*/
			Employee reff=service.deleteEmployee(employee);
			
			if(reff!=null)
			{
				model.addAttribute("delemp", reff);
				viewname="dele";
			}
			else{
				model.addAttribute("message","ID not found");
				viewname="error";
				}
		return viewname;
	}
	@RequestMapping("delete")
	public String moveToDelete(Model model)
	{
		Employee employee=new Employee();
		model.addAttribute("employee", employee);
		return "del";
		
	}

}
